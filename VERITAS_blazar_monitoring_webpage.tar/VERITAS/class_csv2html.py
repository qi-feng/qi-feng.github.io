#!/usr/bin/python
from __future__ import print_function

__author__ = 'qfeng'

import sys
#import pandas as pd
import os
#import numpy as np
import datetime
from datetime import timedelta
from datetime import date as dt

import sys
import pymysql
import urllib

from optparse import OptionParser

class LTP_blazar_html(object):

    def __init__(self):
        self.DB_HOST='romulus.ucsc.edu'
        self.DB_USER='readonly'
        self.DB_PASSWD=''
        self.DB_ONLINE='VERITAS'
        self.DB_OFFLINE='VOFFLINE'

        self.parent_dir="/homes/shavante/qifeng/WWW/VERITAS/"
        #self.parent_dir="/Users/qfeng/test/VERITAS/"
        self.parent_address="http://www.physics.mcgill.ca/~qifeng/VERITAS/"
        self.source_address=self.parent_address+"sources/"
        self.parent_ssh="qifeng@choco.physics.mcgill.ca:~/WWW/VERITAS/"
        self.sources_ssh=self.parent_ssh+"sources/"
        self.dates_ssh=self.parent_ssh+"dates/"
        self.start_date="2007-09-01"
        
        self.LTP_Blazars=['1ES0229+200', 'RBS 0413', '1ES 0414+009', '1ES0502+675',
                     'VER J0521+211', 'RX J0648.7+1516', 'RGBJ0710+591', 'S5 0716+714',
                     '1ES0806+524', '1ES1215+303', '1ES1218+304', 'PKS 1424+240',
                     'H1426+428', 'PG1553+113', '1ES1959+650', '1ES2344+514',
                     '3C66A', 'W Comae', 'BL Lac', 'Mrk421', 'Mrk501', 'M87']

        self.print_names = ['1ES 0229+200', 'RBS 0413', '1ES 0414+009', '1ES 0502+675',
               'VER J0521+211', 'RX J0648.7+1516', 'RGB J0710+591', 'S5 0716+714',
               '1ES 0806+524', '1ES 1215+303', '1ES 1218+304', 'PKS 1424+240',
               'H 1426+428', 'PG 1553+113', '1ES 1959+650', '1ES 2344+514',
               '3C 66A', 'W Comae', 'BL Lac', 'Mrk 421', 'Mrk 501', 'M87']
        self.ras = [u'02h32m48.5944s', u'03h19m51.7958s', u'04h16m53.0001s',
               u'05h07m56.3075s', u'05h21m46.0008s', u'06h48m47.6494s',
               u'07h10m30.1017s', u'07h21m53.402s', u'08h09m49.2009s',
               u'12h17m52.1005s', u'12h21m21.8993s', u'14h27m00.3967s',
               u'14h28m32.597s', u'15h55m43.005s', u'19h59m59.7971s',
               u'23h47m04.7976s', u'02h22m39.6044s', u'12h21m31.7037s',
               u'22h02m43.2994s', u'11h04m27.3018s', u'16h53m52.1942s',
               u'12h30m49.40s']
        self.decs = [u'+20d17m16.924s', u'+18d45m34.8103s', u'+01d04m54.0733s',
               u'+67d37m24.0376s', u'+21d12m51.4009s', u'+15d16m24.8345s',
               u'+59d08m20.9639s', u'+71d20m36.3989s', u'+52d18m57.9194s',
               u'+30d07m01.0328s', u'+30d10m36.992s', u'+23d47m59.9253s',
               u'+42d40m28.9154s', u'+11d11m23.9292s', u'+65d08m55.0481s',
               u'+51d42m18.1052s', u'+43d02m07.9711s', u'+28d13m59.0459s',
               u'+42d16m39.9128s', u'+38d12m32.0176s', u'+39d45m37.0498s', 
               u'+12d23m28.1s']
        self.descriptions = ['BLLac QSO B0229+200', 'QSO QSO B0317+18',
               'BLLac QSO B0414+009', 'BLLac QSO B0502+675',
               'Hard spectrum Fermi source consistent with RGB J0521+212',
               '1FGL J0648.8+1516', 'BLLac QSO B0706+591',
               'BLLac 8C 0716+714; 1H0717+714; RGB J0721+713',
               'BLLac QSO B0806+524', 'QSO QSO B1215+303',
               'BLLac FBQS J1221+3010', '7C 1424+2401',
               'BLLac QSO B1426+428', 'Blazar QSO B1553+113',
               'BLLac [WB92] 1959+6500', 'BLLac [WB92] 2344+5125',
               'BLLac 3C 66A', 'BLLac 7C 1219+2830',
               'QSO QSO B2200+420', 'BLLac QSO B1101+384',
               'BLLac 4C 39.49', 'LINER M 87']

    def connect(self):
        self.conn = pymysql.connect(host=self.DB_HOST,
                                    user=self.DB_USER,
                                    passwd=self.DB_PASSWD,
                                    db=self.DB_ONLINE)
        self.cur = self.conn.cursor()

    def make_html_one_source(self, source, all_after_date=None):
        if all_after_date is None:
            all_after_date = self.start_date

        if source not in self.LTP_Blazars: # and source not in self.print_names:
            print("You gave a source not in the list")
            print("available sources are %s" % self.LTP_Blazars)
            return

        source_index = self.LTP_Blazars.index(source)
        #remove whitespace in filenames and urls
        source_url = self.parent_dir+"sources/"+str(source).replace(" ", "")+".html"
        source_csv = self.parent_dir+"sources/"+str(source).replace(" ", "")+".csv"
        source_csv_link = self.parent_address+"sources/"+str(source).replace(" ", "")+".csv"

        #print("source url is %s" % source_url)
        htmlfile = open(source_url,"w")
        csvfile = open(source_csv,"w")

        htmlfile.write('<html>')
        htmlfile.write('<head>\n')
        htmlfile.write('<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">\n')
        htmlfile.write('<title>\n')
        htmlfile.write('VERITAS Blazar Monitoring: %s \n' % source)
        htmlfile.write('</title>\n')
        htmlfile.write('</head>\n')
        htmlfile.write('<body>\n')
        htmlfile.write('<div style="text-align: center;"><big><big>VERITAS Blazar Monitoring: %s <br /></big></big></div>\n' % source)

        self.connect()
        # query desired columns, this should be consistent with the later columns to write to the html file
        #query=("SELECT data_start_time, db_end_time, duration, weather, run_status "
        #       "FROM tblRun_Info "
        #       "WHERE DATE(data_start_time) = '{}' AND source_id = {}".format(date,source))
        #query=("SELECT data_start_time, db_end_time, duration, weather "
        query=("SELECT data_start_time, db_end_time, duration "
               "FROM tblRun_Info "
               "WHERE DATE(data_start_time) >= '{}' AND source_id = '{}' ORDER BY data_start_time DESC".format(all_after_date,source))

        #self.source_cols = ['source', 'ra', 'dec',
        #                    'start time', 'end time', 'duration', 'weather',
        #                    'band', 'unit', 'telescope', 'description']
        self.source_cols = ['source', 'ra', 'dec',
            'start time', 'end time', 'duration']
        ###VDB scr:
        """
        "SELECT source_id, db_start_time, db_end_time FROM tblRun_Info WHERE db_start_time>\"$DATE\";")
        "SELECT source_id, ra, decl, description FROM tblObserving_Sources;"
        "SELECT source_id, db_start_time, db_end_time FROM tblRun_Info WHERE db_start_time>\"$DATE\" INTO OUTFILE $outfile FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\n';")
        """

        nentries=self.cur.execute(query)
        print(nentries,'found')

        # write link to csv file:
        htmlfile.write('<a href="%s">Click for csv file.</a>\n'%source_csv_link)



        # write <table> tag
        htmlfile.write('<table border="1" width="1000">\n')

        # write header row. assumes first row in csv contains header
        htmlfile.write('<tr>\n') # write <tr> tag
        for column in self.source_cols:
            htmlfile.write('<th>' + str(column) + '</th>\n')
            csvfile.write(str(column) + ', ')
        htmlfile.write('</tr>\n')
        csvfile.write('\n')
        # write table contents
        for row in self.cur:
            #print
            htmlfile.write('<tr>\n')
            htmlfile.write('<td>' + str(source) + '</td>\n')
            htmlfile.write('<td>' + str(self.ras[source_index]) + '</td>\n')
            htmlfile.write('<td>' + str(self.decs[source_index]) + '</td>\n')
            #htmlfile.write('<td> {:14s} </td>\n <td> {} </td>\n <td> {} </td>\n <td> {:2s} </td>\n'.format(*row))
            htmlfile.write('<td> {} </td>\n <td> {} </td>\n <td> {} </td>\n'.format(*row))
            csvfile.write(str(source)+', '+ str(self.ras[source_index]) + ', '+ str(self.decs[source_index])+', ')
            csvfile.write('{}, {}, {} \n'.format(*row))
            #htmlfile.write('<td> {} </td>\n <td> {} </td>\n <td> {} </td>\n <td> {:2s} </td>\n'.format(*row))
            #htmlfile.write('<td>' + str('0.1-30') + '</td>\n')
            #htmlfile.write('<td>' + str('TeV') + '</td>\n')
            #htmlfile.write('<td>' + str('VERITAS') + '</td>\n')
            #htmlfile.write('<td>' + str(self.descriptions[source_index]) + '</td>\n')
            htmlfile.write('</tr>\n')

        # write </table> tag
        htmlfile.write('</table>\n')
        htmlfile.write('</body>\n')
        htmlfile.write('</html>\n')

        htmlfile.close()
        csvfile.close()

        # print results to shell

        try:
            print("Sending to McGill website...")
            os.system("scp %s %s" % (source_url, self.sources_ssh))
        except:
            print("Can't ssh to McGill website.")
        print("Done!")

    def make_source_table_html(self):
        self.source_table_filename=self.parent_dir+"/source_table_page.html"
        #cols = ['source', 'ra', 'dec', 'description']
        cols = ['source', 'ra', 'dec']
        #df = pd.DataFrame(columns=cols)
        #df.columns=cols

        # Create the HTML file for output
        htmlfile = open(self.source_table_filename,"w")

        htmlfile.write('<html>')
        htmlfile.write('<head>\n')
        htmlfile.write('<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">\n')
        htmlfile.write('<title>\n')
        htmlfile.write('VERITAS Blazar Monitoring Table\n')
        htmlfile.write('</title>\n')
        htmlfile.write('</head>\n')
        htmlfile.write('<body>\n')
        htmlfile.write('<div style="text-align: center;"><big><big>VERITAS Blazar Monitoring Table <br /></big></big></div>\n')

        #htmlfile.write('<A HREF="javascript:history.go(0)">Click to refresh the page</A>\n')
        #htmlfile.write('<FORM> <INPUT TYPE="button" onClick="history.go(0)" VALUE="Refresh"> </FORM>\n')

        # write <table> tag
        htmlfile.write('<table border="1" width="1000">\n')

        # generate table contents
        # write header row. assumes first row in csv contains header
        htmlfile.write('<tr>\n') # write <tr> tag
        for column in cols:
            htmlfile.write('<th>' + str(column) + '</th>\n')
        htmlfile.write('</tr>\n')

        nRows=len(self.LTP_Blazars)
        for i in range(nRows):
            htmlfile.write('<tr>\n')
            #remove white spaces in filenames and urls
            source_url = self.source_address+urllib.quote_plus(str(self.LTP_Blazars[i]).replace(" ", ""))+".html"
            #print("source url is %s" % source_url)
            htmlfile.write('<td> <a href=\"'+source_url+'\">')
            htmlfile.write(str(self.print_names[i]) + '</td>\n')
            htmlfile.write('<td>' + str(self.ras[i]) + '</td>\n')
            htmlfile.write('<td>' + str(self.decs[i]) + '</td>\n')
            #htmlfile.write('<td>' + str(self.descriptions[i]) + '</td>\n')
            htmlfile.write('</tr>\n')

        # write </table> tag
        htmlfile.write('</table>\n')
        htmlfile.write('</body>\n')
        htmlfile.write('</html>\n')

        htmlfile.close()

        # print results to shell
        print("Created a " + str(nRows) + " row table.")

        try:
            print("Sending to McGill website...")
            os.system("scp %s qifeng@choco.physics.mcgill.ca:~/WWW/VERITAS/" % self.source_table_filename)
        except:
            print("Can't ssh to McGill website.")
        print("Done!")

    def make_date_table_html(self, date=None, update_source_tables=True):
        if date is None:
            date=dt.today().isoformat()

        source_url = self.parent_dir+"dates/VERITAS_blazar_log_"+str(date)+".html"
        source_csv = self.parent_dir+"dates/VERITAS_blazar_log_"+str(date)+".csv"
        source_csv_link = self.parent_address+"dates/VERITAS_blazar_log_"+str(date)+".csv"
        #print("source url is %s" % source_url)
        htmlfile = open(source_url,"w")
        csvfile = open(source_csv, "w")

        htmlfile.write('<html>')
        htmlfile.write('<head>\n')
        htmlfile.write('<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">\n')
        htmlfile.write('<title>\n')
        htmlfile.write('VERITAS Blazar Monitoring: %s \n' % date)
        htmlfile.write('</title>\n')
        htmlfile.write('</head>\n')
        htmlfile.write('<body>\n')
        htmlfile.write('<div style="text-align: center;"><big><big>VERITAS Blazar Monitoring: %s <br /></big></big></div>\n' % date)

        self.connect()
        # query desired columns, this should be consistent with the later columns to write to the html file
        #query=("SELECT data_start_time, db_end_time, duration, weather, run_status "
        #       "FROM tblRun_Info "
        #       "WHERE DATE(data_start_time) = '{}' AND source_id = {}".format(date,source))
        LTP_String="('" + "','".join(self.LTP_Blazars) + "')"  # make list of blazars into a string for SQL Query...

        #query=("SELECT source_id, data_start_time, db_end_time, duration, weather "
        query=("SELECT source_id, data_start_time, db_end_time, duration "
               "FROM tblRun_Info "
               "WHERE DATE(data_start_time) = '{}' AND source_id IN {} ORDER BY data_start_time DESC".format(date, LTP_String))

        self.source_cols = ['source', 'ra', 'dec',
                            'start time', 'end time', 'duration'] #, 'weather',
                            #'band', 'unit', 'telescope', 'description']
        ###VDB scr:
        """
        "SELECT source_id, db_start_time, db_end_time FROM tblRun_Info WHERE db_start_time>\"$DATE\";")
        "SELECT source_id, ra, decl, description FROM tblObserving_Sources;"
        "SELECT source_id, db_start_time, db_end_time FROM tblRun_Info WHERE db_start_time>\"$DATE\" INTO OUTFILE $outfile FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\n';")
        """


        nentries=self.cur.execute(query)
        print(nentries,'found')

        #add link
        htmlfile.write('<a href="%s">Click for csv file.</a>\n'%source_csv_link)

        # write <table> tag
        htmlfile.write('<table border="1" width="1000">\n')

        # write header row. assumes first row in csv contains header
        htmlfile.write('<tr>\n') # write <tr> tag
        for column in self.source_cols:
            htmlfile.write('<th>' + str(column) + '</th>\n')
            csvfile.write(str(column) + ', ')
        htmlfile.write('</tr>\n')
        csvfile.write('\n')
        today_src_set=set()
        # write table contents, iterate through sources
        for row in self.cur:
            #print
            source_index = self.LTP_Blazars.index(row[0])
            htmlfile.write('<tr>\n')
            htmlfile.write('<td>' + str(row[0]) + '</td>\n')
            htmlfile.write('<td>' + str(self.ras[source_index]) + '</td>\n')
            htmlfile.write('<td>' + str(self.decs[source_index]) + '</td>\n')
            #htmlfile.write('<td> {:14s} </td>\n <td> {} </td>\n <td> {} </td>\n <td> {:2s} </td>\n'.format(*row))
            htmlfile.write('<td> {} </td>\n <td> {} </td>\n <td> {} </td>\n'.format(*row[1:]))
            #htmlfile.write('<td> {} </td>\n <td> {} </td>\n <td> {} </td>\n <td> {:2s} </td>\n'.format(*row[1:]))
            #htmlfile.write('<td>' + str('0.1-30') + '</td>\n')
            #htmlfile.write('<td>' + str('TeV') + '</td>\n')
            #htmlfile.write('<td>' + str('VERITAS') + '</td>\n')
            #htmlfile.write('<td>' + str(self.descriptions[source_index]) + '</td>\n')
            htmlfile.write('</tr>\n')
            csvfile.write(str(row[0])+', '+ str(self.ras[source_index]) + ', '+ str(self.decs[source_index])+', ')            
            csvfile.write('{}, {}, {} \n'.format(*row[1:]))
            if update_source_tables and row[0] not in today_src_set:
                #update the source table:
                self.make_html_one_source(row[0], all_after_date=self.start_date)
                today_src_set.add(row[0])

        # write </table> tag
        htmlfile.write('</table>\n')
        htmlfile.write('</body>\n')
        htmlfile.write('</html>\n')

        htmlfile.close()
        csvfile.close()
        # print results to shell

        try:
            print("Sending to McGill website...")
            os.system("scp %s %s" % (source_url, self.dates_ssh))
        except:
            print("Can't ssh to McGill website.")
        print("Done!")

    def make_many_days_html(self, start_date=None, end_date=None, update_source_tables=False):
        if all_after_date is None:
            all_after_date = self.start_date

        start_date = dt(int(start_date.split("-")[0]), int(start_date.split("-")[1]), int(start_date.split("-")[2]))
        if end_date is None:
            #today
            end_date = dt.today().isoformat()
        end_date = dt(int(end_date.split("-")[0]), int(end_date.split("-")[1]), int(end_date.split("-")[2]))

        for single_date in self.daterange(start_date, end_date):
            self.make_date_table_html(date=single_date.strftime("%Y-%m-%d"), update_source_tables=update_source_tables)
        if not update_source_tables:
            #now update source table for all dates before end_date
            self.make_date_table_html(date=single_date.strftime("%Y-%m-%d"))
    def daterange(self, start_date, end_date):
        for n in range(int ((end_date - start_date).days)):
            yield start_date + timedelta(n)



if __name__ == "__main__":
    parser = OptionParser()
    parser.add_option("-i","--init",action="store_true", dest="init", default=False, help="Create html files for the first time, run mkdir dates and mkdir sources first.")
    parser.add_option("-d","--date",dest="date", default="2009-01-01", help="Date if you don't want today.")
    parser.add_option("-e","--enddate",dest="enddate", default=None, help="End date if you don't want to end today.")
    (options, args) = parser.parse_args()
    ltp = LTP_blazar_html()
    if options.init:
        #Makeing the master source table
        ltp.make_source_table_html()
    
        #Making the individual source tables
        #(the clickable source names in the master source table will open these)
        for s in ltp.LTP_Blazars:
            ltp.make_html_one_source(s, all_after_date=options.date)

        #Making obs tables of a given date
        #ltp.make_date_table_html(date="2009-01-01")

        #Making obs tables of a range of dates
        ltp.make_many_days_html(start_date=options.date, end_date=options.enddate)
    else:
        #Making obs tables for today: 
        ltp.make_date_table_html()


